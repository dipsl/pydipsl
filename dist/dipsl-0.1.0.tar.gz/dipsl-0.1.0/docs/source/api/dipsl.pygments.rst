dipsl.pygments package
======================

Submodules
----------

dipsl.pygments.DIP\_Lexer\_Schema module
----------------------------------------

.. automodule:: dipsl.pygments.DIP_Lexer_Schema
   :members:
   :undoc-members:
   :show-inheritance:

dipsl.pygments.DIP\_Lexer\_Style module
---------------------------------------

.. automodule:: dipsl.pygments.DIP_Lexer_Style
   :members:
   :undoc-members:
   :show-inheritance:

dipsl.pygments.DIP\_Lexer\_Syntax module
----------------------------------------

.. automodule:: dipsl.pygments.DIP_Lexer_Syntax
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dipsl.pygments
   :members:
   :undoc-members:
   :show-inheritance:
