dipsl.settings package
======================

Module contents
---------------

.. automodule:: dipsl.settings
   :members:
   :undoc-members:
   :show-inheritance:
