from .DIP_Type import Type
from .DIP_Type_Boolean import BooleanType
from .DIP_Type_Number import NumberType
from .DIP_Type_Float import FloatType
from .DIP_Type_Integer import IntegerType
from .DIP_Type_String import StringType
